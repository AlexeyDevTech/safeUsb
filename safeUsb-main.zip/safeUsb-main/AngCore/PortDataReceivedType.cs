﻿namespace AngCore.Enums
{
    public enum PortDataReceivedType
    {
        String,
        Byte
    }
}
